#include <iostream>
#include <chrono>
#include <ucontext.h>

void dummy() {}

int main() {
    ucontext_t ctx1, ctx2;
    char stack1[1024*64], stack2[1024*64];

    getcontext(&ctx1);
    ctx1.uc_stack.ss_sp = stack1;
    ctx1.uc_stack.ss_size = sizeof(stack1);
    ctx1.uc_link = &ctx2;
    makecontext(&ctx1, dummy, 0);

    getcontext(&ctx2);
    ctx2.uc_stack.ss_sp = stack2;
    ctx2.uc_stack.ss_size = sizeof(stack2);
    ctx2.uc_link = &ctx1;
    makecontext(&ctx2, dummy, 0);

    const int iterations = 10000;
    auto start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < iterations; ++i) {
        swapcontext(&ctx1, &ctx2);
        swapcontext(&ctx2, &ctx1);
    }
    auto end = std::chrono::high_resolution_clock::now();
    double avg = std::chrono::duration<double, std::micro>(end - start).count() / (iterations * 2);

    std::cout << "[ULT] Avg context switch time: " << avg << " µs" << std::endl;
    return 0;
}
